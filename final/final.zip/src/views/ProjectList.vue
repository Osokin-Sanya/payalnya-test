<template>
  <div class="p-2">
    <div class="header">
      <h1>Projects</h1>
      <button @click="showCreateModal = true" class="btn-primary">
        Add Project
      </button>
    </div>

    <div>
      <DebouncedInput
        :modelValue="globalFilter ?? ''"
        @update:modelValue="(value:any) => (globalFilter = String(value))"
        className="p-2 font-lg shadow border border-block"
        placeholder="Search all columns..."
      />
    </div>
    <table>
      <thead>
        <tr
          v-for="headerGroup in table.getHeaderGroups()"
          :key="headerGroup.id"
        >
          <th
            v-for="header in headerGroup.headers"
            :key="header.id"
            :colSpan="header.colSpan"
          >
            <FlexRender
              v-if="!header.isPlaceholder"
              :render="header.column.columnDef.header"
              :props="header.getContext()"
            />
            <template
              v-if="
                header.column.getCanFilter() &&
                !header.column.columnDef.meta?.enableFiltering
              "
            >
              <Filter :column="header.column" :table="table" />
            </template>
          </th>
        </tr>
      </thead>
    </table>
    <table>
      <thead>
        <tr
          v-for="headerGroup in table.getHeaderGroups()"
          :key="headerGroup.id"
        >
          <th
            v-for="header in headerGroup.headers"
            :key="header.id"
            :colSpan="header.colSpan"
            :class="
              header.column.getCanSort() ? 'cursor-pointer select-none ' : ''
            "
            @click="header.column.getToggleSortingHandler()?.($event)"
          >
            <template v-if="!header.isPlaceholder" class="column-name">
              <div class="column-name">
                <div>
                  <FlexRender
                    :render="header.column.columnDef.header"
                    :props="header.getContext()"
                  />
                </div>
                <div>
                  {{
                    { asc: " 🔼", desc: " 🔽" }[
                      header.column.getIsSorted() as string
                    ]
                  }}
                </div>
              </div>
            </template>
          </th>
        </tr>
      </thead>

      <tbody>
        <tr
          v-for="row in table.getRowModel().rows.slice(0, 10)"
          :key="row.id"
          @click="navigateToProject(row.original.id)"
        >
          <td v-for="cell in row.getVisibleCells()" :key="cell.id">
            <FlexRender
              :render="cell.column.columnDef.cell"
              :props="cell.getContext()"
            />
          </td>
        </tr>
      </tbody>

      <tfoot>
        <tr
          v-for="footerGroup in table.getFooterGroups()"
          :key="footerGroup.id"
        >
          <th
            v-for="header in footerGroup.headers"
            :key="header.id"
            :colSpan="header.colSpan"
          >
            <FlexRender
              v-if="!header.isPlaceholder"
              :render="header.column.columnDef.footer"
              :props="header.getContext()"
            />
          </th>
        </tr>
      </tfoot>
    </table>

    <div v-if="showCreateModal" class="modal">
      <div class="modal-content">
        <h2>Create New Project</h2>
        <form @submit.prevent="createProject">
          <div class="form-group">
            <label for="name">Project Name *</label>
            <input
              v-model="newProject.name"
              id="name"
              type="text"
              required
              class="form-input"
            />
          </div>
          <div class="form-group">
            <label for="description">Description</label>
            <textarea
              v-model="newProject.description"
              id="description"
              class="form-input"
            ></textarea>
          </div>
          <div class="form-actions">
            <button
              type="button"
              @click="showCreateModal = false"
              class="btn-secondary"
            >
              Cancel
            </button>
            <button type="submit" class="btn-primary">Create</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, watch, onMounted, computed } from "vue";
import { useProjectStore } from "@/stores/projects";
import { useTaskStore } from "@/stores/tasks";
import {
  FlexRender,
  getCoreRowModel,
  useVueTable,
  createColumnHelper,
  getSortedRowModel,
  getFacetedMinMaxValues,
  getFacetedRowModel,
  getFacetedUniqueValues,
  getFilteredRowModel,
} from "@tanstack/vue-table";
import type { ColumnFiltersState } from "@tanstack/table-core";

import type { Project, ProjectWithTasks } from "@/types";
import DebouncedInput from "@/utils/DebouncedInput.vue";
import Filter from "@/utils/Filter.vue";
import { useRouter } from "vue-router";

const projectStore = useProjectStore();
const taskStore = useTaskStore();
const dataProject = ref<Project[]>([]);
const showCreateModal = ref(false);
const columnHelper = createColumnHelper<ProjectWithTasks>();
const columnFilters = ref<ColumnFiltersState>([]);
const globalFilter = ref("");
const currentTask = ref<any>([]);
const router = useRouter();
const navigateToProject = (projectId: string) => {
  router.push(`/project/${projectId}`);
};
const newProject = ref({
  name: "",
  description: "",
});

const quantityTask = (projectsId: string) => {
  if (!taskStore.tasks || taskStore.tasks.length === 0) return 0;

  currentTask.value = taskStore.getTasksByProject(projectsId);
  return currentTask.value.length || 0;
};
const projectsWithTasks = computed<ProjectWithTasks[]>(() => {
  return dataProject.value.map((project) => ({
    ...project,
    tasks: taskStore.getTasksByProject(project.id).length,
  }));
});
const columns = [
  columnHelper.group({
    header: "Projects",
    columns: [
      columnHelper.accessor("id", {
        header: () => "Id",
        cell: (info) => info.getValue(),
      }),
      columnHelper.accessor("name", {
        header: () => "Name",
        cell: (info) => info.getValue(),
      }),
      columnHelper.accessor("description", {
        header: () => "Description",
        cell: (info) => info.getValue(),
        meta: {
          enableFiltering: true,
        },
      }),
      columnHelper.accessor("status", {
        header: () => "Status",
        cell: (info) => info.getValue(),
      }),
      columnHelper.accessor("tasks", {
        header: () => "Tasks",
        cell: (info) => info.getValue(),
      }),
      columnHelper.accessor("createdAt", {
        header: () => "Creation",
        cell: (info) => {
          const timestamp = info.getValue();
          const date = new Date(timestamp);
          return date.toLocaleDateString();
        },
        meta: {
          enableFiltering: true,
        },
      }),
    ],
  }),
];

const sorting = ref<any>([]);

const table = useVueTable({
  get data() {
    return projectsWithTasks.value;
  },
  columns,
  state: {
    get sorting() {
      return sorting.value;
    },
    get columnFilters() {
      return columnFilters.value;
    },
    get globalFilter() {
      return globalFilter.value;
    },
  },
  onSortingChange: (updaterOrValue) => {
    sorting.value =
      typeof updaterOrValue === "function"
        ? updaterOrValue(sorting.value)
        : updaterOrValue;
  },
  onColumnFiltersChange: (updaterOrValue) => {
    columnFilters.value =
      typeof updaterOrValue === "function"
        ? updaterOrValue(columnFilters.value)
        : updaterOrValue;
  },
  onGlobalFilterChange: (updaterOrValue) => {
    globalFilter.value =
      typeof updaterOrValue === "function"
        ? updaterOrValue(globalFilter.value)
        : updaterOrValue;
  },
  getCoreRowModel: getCoreRowModel(),
  getSortedRowModel: getSortedRowModel(),
  getFilteredRowModel: getFilteredRowModel(),
  getFacetedRowModel: getFacetedRowModel(),
  getFacetedUniqueValues: getFacetedUniqueValues(),
  getFacetedMinMaxValues: getFacetedMinMaxValues(),
  debugTable: true,
});

watch(
  () => projectStore.projects,
  () => {
    dataProject.value = projectStore.projects;
  }
);

const createProject = async () => {
  try {
    await projectStore.createProject({
      name: newProject.value.name,
      description: newProject.value.description,
      status: "new",
      createdAt: Date.now(),
    });
    showCreateModal.value = false;
    newProject.value = { name: "", description: "" };
  } catch (error) {
    console.error("Failed to create project:", error);
  }
};

onMounted(async () => {
  try {
    await projectStore.fetchProjects();
    await taskStore.fetchProjectTasks();
    dataProject.value = projectStore.projects.map((project) => ({
      ...project,
      tasks: taskStore.getTasksByProject(project.id).length,
      enableFiltering: false,
    }));
    for (const project of projectStore.projects) {
      await projectStore.updateProjectStatus(project.id);
    }
  } catch (err) {
    console.error(err);
  }
});
</script>

<style lang="scss" scoped>
.p-2 {
  padding: 1rem;
  font-family: Arial, sans-serif;
  color: #333;

  .header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;

    h1 {
      font-size: 1.5rem;
      font-weight: bold;
      margin: 0;
    }

    .btn-primary {
      padding: 0.5rem 1rem;
      background-color: #4caf50;
      color: #fff;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 1rem;

      &:hover {
        background-color: #45a049;
      }
    }
  }

  table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 1rem;

    thead {
      background-color: #f4f4f4;

      th {
        padding: 0.5rem;
        text-align: left;
        border-bottom: 1px solid #ddd;

        &.cursor-pointer {
          cursor: pointer;
          user-select: none;
        }
      }

      .column-name {
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
    }

    tbody {
      tr {
        transition: background-color 0.2s;
        cursor: zoom-in;
        &:hover {
          background-color: #f9f9f9;
        }

        td {
          padding: 0.5rem;
          border-bottom: 1px solid #ddd;
        }
      }
    }

    tfoot {
      th {
        padding: 0.5rem;
        background-color: #f4f4f4;
      }
    }
  }

  .modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;

    .modal-content {
      background-color: #fff;
      padding: 1.5rem;
      border-radius: 8px;
      width: 100%;
      max-width: 500px;

      h2 {
        margin-top: 0;
        margin-bottom: 1rem;
        font-size: 1.25rem;
        text-align: center;
      }

      .form-group {
        margin-bottom: 1rem;

        label {
          display: block;
          margin-bottom: 0.5rem;
          font-weight: bold;
        }

        .form-input {
          width: 100%;
          padding: 0.5rem;
          border: 1px solid #ccc;
          border-radius: 4px;
          font-size: 1rem;

          &:focus {
            outline: none;
            border-color: #4caf50;
            box-shadow: 0 0 3px rgba(76, 175, 80, 0.5);
          }
        }

        textarea {
          resize: vertical;
          min-height: 80px;
        }
      }

      .form-actions {
        display: flex;
        justify-content: flex-end;
        gap: 0.5rem;

        .btn-secondary {
          background-color: #ccc;
          color: #333;
          border: none;
          padding: 0.5rem 1rem;
          border-radius: 4px;
          cursor: pointer;

          &:hover {
            background-color: #bbb;
          }
        }

        .btn-primary {
          background-color: #4caf50;
          color: #fff;
          border: none;
          padding: 0.5rem 1rem;
          border-radius: 4px;
          cursor: pointer;

          &:hover {
            background-color: #45a049;
          }
        }
      }
    }
  }
}
</style>
