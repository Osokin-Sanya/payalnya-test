<script lang="ts" setup>
import BoxWithImage from './BoxWithImage.vue'
import BoxWithHandle from './BoxWithHandle.vue'
</script>
<template>
  <div>
    <div style="margin-top: 1.5rem">
      <BoxWithHandle />
      <BoxWithImage />
    </div>
  </div>
</template>
