export const ItemTypes = {
  BOX: 'box',
}
