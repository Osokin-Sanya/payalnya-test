import Container from './Container.vue'

export default Container
