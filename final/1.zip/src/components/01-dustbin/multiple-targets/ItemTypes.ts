export const ItemTypes = {
  FOOD: 'food',
  GLASS: 'glass',
  PAPER: 'paper',
}
