import Example from './Example.vue'

export default Example
