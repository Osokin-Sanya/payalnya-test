export interface DragItem {
  type: string
}
