export const Colors = {
  YELLOW: 'yellow',
  BLUE: 'blue',
}
