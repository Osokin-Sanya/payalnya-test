<script setup lang="ts">
import { HTML5Backend } from "react-dnd-html5-backend";
import { RouterLink, RouterView } from "vue-router";
import { DndProvider } from "vue3-dnd";
</script>

<template>
   <DndProvider :backend="HTML5Backend">
    <RouterView />
  </DndProvider>
</template>

<style lang="scss" scoped></style>
