import Dustbin from "@/components/01-dustbin/copy-or-move/Dustbin.vue";
import Example from "@/components/02-drag-around/naive/Example.vue";
import StatefulTargetBox from "@/components/03-nesting/drag-sources/StatefulTargetBox.vue";
// import TargetBox from "@/components/03-nesting/drag-sources/TargetBox.vue";
// import Card from "@/components/04-sortable/cancel-on-drop-outside/Card.vue";
import Card from "@/components/04-sortable/indicator/Card.vue";
import BoxWithHandle from "@/components/05-customize/handles-and-previews/BoxWithHandle.vue";
// import TargetBox from "@/components/05-customize/drop-effects/TargetBox.vue";
import TargetBox from "@/components/06-other/native-files/TargetBox.vue";
 
import ProjectDetails from "@/views/ProjectDetails.vue";
import ProjectList from "@/views/ProjectList.vue";
import { createRouter, createWebHistory } from "vue-router";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/",
      name: "projects",
      component: ProjectList,
    },
    {
      path: "/project/:id",
      name: "project-details",
      component: ProjectDetails,
      props: true,
    },
    {
      path: "/details",
      name: "project-details",
      component: BoxWithHandle,
      props: true,
    },
  ],
});

export default router;
