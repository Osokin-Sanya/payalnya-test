<script setup lang="ts">
import { useDrag } from "vue3-dnd";
import { toRefs } from "@vueuse/core";

const [collect, drag, dragPreview] = useDrag(() => ({
  type: "BOX",
  collect: (monitor) => ({
    isDragging: monitor.isDragging(),
  }),
}));

const { isDragging } = toRefs(collect);
</script>

<template>
  <div :ref="dragPreview" :style="{ opacity: isDragging ? 0.5 : 1 }">
    <div role="Handle" :ref="drag" />
    asasas
  </div>
</template>
