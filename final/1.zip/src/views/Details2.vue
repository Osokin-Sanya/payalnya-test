<script setup lang="ts">
import { useDrop } from "vue3-dnd";
import { toRefs } from "@vueuse/core";

const [collect, drop] = useDrop(() => ({
  accept: "BOX",

  collect: (monitor) => ({
    isOver: monitor.isOver(),
    canDrop: monitor.canDrop(),
  }),
}));
const { canDrop, isOver } = toRefs(collect);
</script>

<template>
  <div :ref="drop" :style="{ backgroundColor: isOver ? 'red' : 'white' }">
    {{ canDrop ? "Release to drop" : "Drag a box here" }}
  </div>
</template>
