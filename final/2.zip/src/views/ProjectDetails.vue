<template>
  <div class="flex justify-between m-10">
    <div class="task-board">
      <div
        v-for="status in taskStatuses"
        :key="status"
        :data-status="status"
        class="task-column"
        :class="status"
      >
        <h3 class="column-title">
          {{ formatStatus(status) }}
          <span class="task-count">{{ localTasks[status].length }}</span>
        </h3>
        <VueDraggableNext
          class="dragArea list-group"
          :list="localTasks[status]"
          @end="handleDragEnd"
          :group="{ name: 'shared', pull: true, put: true }"
        >
          <div
            class="list-group-item"
            v-for="task in localTasks[status]"
            :key="task.id"
            :data-id="task.id"
          >
            <div class="task-card">
              <div class="task-header">
                <h4>{{ task.name }}</h4>
                <button class="delete-btn" @click="deleteTask(task.id)">
                  ×
                </button>
              </div>

              <div class="task-meta">
                <span v-if="task.assignedTo" class="assignee">
                  {{ getUserName(task.assignedTo) }}
                </span>
                <div class="task-dates">
                  <span v-if="task.endDate" class="due-date">
                    Due: {{ formatDate(task.endDate) }}
                  </span>
                  <span class="due-date"> ID: {{ task.id }} </span>
                </div>
              </div>
            </div>
          </div>
        </VueDraggableNext>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useProjectStore } from "@/stores/projects";
import { useTaskStore } from "@/stores/tasks";
import { useUserStore } from "@/stores/users";
import type { Task, TaskStatus } from "@/types";
import { computed, onMounted, ref, watch } from "vue";
import { VueDraggableNext } from "vue-draggable-next";
import { useRoute, useRouter } from "vue-router";
const taskStatuses = <TaskStatus[]>["new", "in-progress", "done"];
const route = useRoute();
const router = useRouter();
const projectStore = useProjectStore();
const taskStore = useTaskStore();
const userStore = useUserStore();
const projectId = computed(() => route.params.id);
const project = computed(() =>
  projectStore.getProjectById(projectId.toString())
);

const localTasks = ref<Record<string, Task[]>>({
  new: [],
  "in-progress": [],
  done: [],
});
const deleteTask = async (taskId: string) => {
  console.log(taskId);

  // if (confirm("Are you sure you want to delete this task?")) {
  //   await taskStore.deleteTask(taskId);
  // }
};
const handleDragEnd = async (event: any) => {
  const { oldIndex, newIndex } = event;
  const taskId = event.item.getAttribute("data-id");
  const newStatus = event.to.parentElement.getAttribute("data-status");

  if (!taskId || !newStatus) {
    console.error("Invalid task ID or status");
    return;
  }

  const currentTask = taskStore.tasks.find((task) => task.id === taskId);

  if (!currentTask) {
    console.error("Task not found:", taskId);
    return;
  }

  try {
    const updates: Partial<Task> = {
      ...currentTask,
      status: newStatus,
      order: newIndex,
    };

    await taskStore.updateTask(updates);
    console.log("Task updated successfully:", updates);
  } catch (error) {
    console.error("Failed to update task:", error);
  }
};

const formatStatus = (status: string) => {
  switch (status) {
    case "new":
      return "To Do";
    case "in-progress":
      return "In Progress";
    case "done":
      return "Done";
    default:
      return status;
  }
};
watch(
  () => taskStore.tasks,
  (tasks) => {
    taskStatuses.forEach((status) => {
      localTasks.value[status] = tasks
        .filter((task) => {
          return task.status === status && task.projectId === projectId.value;
        })
        .sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
    });
  },
  { deep: true }
);

const formatDate = (timestamp: number): string => {
  return new Date(timestamp).toLocaleDateString();
};

const getUserName = (userId: string): string => {
  return userStore.getUserById(userId)?.name || "Unknown";
};

onMounted(async () => {
  try {
    if (!project.value) {
      await projectStore.fetchProjects();
    }
    await taskStore.fetchProjectTasks();
    await userStore.fetchUsers();
  } catch (error) {
    console.error("Failed to initialize project details:", error);
    router.push({ name: "projects" });
  }
});
</script>

<style scoped lang="scss">
.dragArea {
  display: flex;
  flex-direction: column;
  height: 90%;
  background: linear-gradient(145deg, #f0f4f8, #e1e9f0);
  border: 2px solid #dfe6eb;
  border-radius: 12px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.list-group-item {
  font-size: 1.125rem;
  font-weight: 600;
  background-color: #ffffff;
  border-radius: 10px;
  margin-bottom: 1rem;
  padding: 12px;
  cursor: grab;
  transition: all 0.2s ease;
}

.list-group-item:hover {
  background-color: #f7fafc;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.dragArea:hover {
  box-shadow: 0 6px 10px rgba(0, 0, 0, 0.15);
}

.dragArea:active .list-group-item {
  cursor: grabbing;
}
.task-board {
  display: flex;
  gap: 1rem;
}
.task-column {
  min-width: 300px;
  background-color: #f7fafc;
  border-radius: 12px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  padding: 1rem;
}
</style>
