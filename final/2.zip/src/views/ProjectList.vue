<template>
  <div class="p-2">
    <div>
      <DebouncedInput
        :modelValue="globalFilter ?? ''"
        @update:modelValue="(value:any) => (globalFilter = String(value))"
        className="p-2 font-lg shadow border border-block"
        placeholder="Search all columns..."
      />
    </div>
    <table>
      <thead>
        <tr
          v-for="headerGroup in table.getHeaderGroups()"
          :key="headerGroup.id"
        >
          <th
            v-for="header in headerGroup.headers"
            :key="header.id"
            :colSpan="header.colSpan"
          >
            <FlexRender
              v-if="!header.isPlaceholder"
              :render="header.column.columnDef.header"
              :props="header.getContext()"
            />
            <template
              v-if="
                header.column.getCanFilter() &&
                !header.column.columnDef.meta?.enableFiltering
              "
            >
              <Filter :column="header.column" :table="table" />
            </template>
          </th>
        </tr>
      </thead>
    </table>
    <table>
      <thead>
        <tr
          v-for="headerGroup in table.getHeaderGroups()"
          :key="headerGroup.id"
        >
          <th
            v-for="header in headerGroup.headers"
            :key="header.id"
            :colSpan="header.colSpan"
            :class="
              header.column.getCanSort() ? 'cursor-pointer select-none ' : ''
            "
            @click="header.column.getToggleSortingHandler()?.($event)"
          >
            <template v-if="!header.isPlaceholder" class="column-name">
              <div class="column-name">
                <div>
                  <FlexRender
                    :render="header.column.columnDef.header"
                    :props="header.getContext()"
                  />
                </div>
                <div>
                  {{
                    { asc: " 🔼", desc: " 🔽" }[
                      header.column.getIsSorted() as string
                    ]
                  }}
                </div>
              </div>
            </template>
          </th>
        </tr>
      </thead>

      <tbody>
        <tr
          v-for="row in table.getRowModel().rows.slice(0, 10)"
          :key="row.id"
          @click="navigateToProject(row.original.id)"
        >
          <td v-for="cell in row.getVisibleCells()" :key="cell.id">
            <FlexRender
              :render="cell.column.columnDef.cell"
              :props="cell.getContext()"
            />
          </td>
        </tr>
      </tbody>

      <tfoot>
        <tr
          v-for="footerGroup in table.getFooterGroups()"
          :key="footerGroup.id"
        >
          <th
            v-for="header in footerGroup.headers"
            :key="header.id"
            :colSpan="header.colSpan"
          >
            <FlexRender
              v-if="!header.isPlaceholder"
              :render="header.column.columnDef.footer"
              :props="header.getContext()"
            />
          </th>
        </tr>
      </tfoot>
    </table>
  </div>
</template>

<script setup lang="ts">
import { ref, watch, onMounted, computed } from "vue";
import { useProjectStore } from "@/stores/projects";
import { useTaskStore } from "@/stores/tasks";
import {
  FlexRender,
  getCoreRowModel,
  useVueTable,
  createColumnHelper,
  getSortedRowModel,
  getFacetedMinMaxValues,
  getFacetedRowModel,
  getFacetedUniqueValues,
  getFilteredRowModel,
} from "@tanstack/vue-table";
import type { ColumnFiltersState } from "@tanstack/table-core";

import type { Project, ProjectWithTasks } from "@/types";
import DebouncedInput from "@/utils/DebouncedInput.vue";
import Filter from "@/utils/Filter.vue";
import { useRouter } from "vue-router";

const projectStore = useProjectStore();
const taskStore = useTaskStore();
const dataProject = ref<Project[]>([]);

const columnHelper = createColumnHelper<ProjectWithTasks>();
const columnFilters = ref<ColumnFiltersState>([]);
const globalFilter = ref("");
const currentTask = ref<any>([]);
const router = useRouter();
const navigateToProject = (projectId: string) => {
  router.push(`/project/${projectId}`);
};

const quantityTask = (projectsId: string) => {
  if (!taskStore.tasks || taskStore.tasks.length === 0) return 0;

  currentTask.value = taskStore.getTasksByProject(projectsId);
  return currentTask.value.length || 0;
};
const projectsWithTasks = computed<ProjectWithTasks[]>(() => {
  return dataProject.value.map((project) => ({
    ...project,
    tasks: taskStore.getTasksByProject(project.id).length,
  }));
});
const columns = [
  columnHelper.group({
    header: "Projects",
    columns: [
      columnHelper.accessor("id", {
        header: () => "Id",
        cell: (info) => info.getValue(),
      }),
      columnHelper.accessor("name", {
        header: () => "Name",
        cell: (info) => info.getValue(),
      }),
      columnHelper.accessor("description", {
        header: () => "Description",
        cell: (info) => info.getValue(),
        meta: {
          enableFiltering: true,
        },
      }),
      columnHelper.accessor("status", {
        header: () => "Status",
        cell: (info) => info.getValue(),
      }),
      columnHelper.accessor("tasks", {
        header: () => "Tasks",
        cell: (info) => info.getValue(),
      }),
      columnHelper.accessor("createdAt", {
        header: () => "Creation",
        cell: (info) => {
          const timestamp = info.getValue();
          const date = new Date(timestamp);
          return date.toLocaleDateString();
        },
        meta: {
          enableFiltering: true,
        },
      }),
    ],
  }),
];

const sorting = ref<any>([]);

const table = useVueTable({
  get data() {
    return projectsWithTasks.value;
  },
  columns,
  state: {
    get sorting() {
      return sorting.value;
    },
    get columnFilters() {
      return columnFilters.value;
    },
    get globalFilter() {
      return globalFilter.value;
    },
  },
  onSortingChange: (updaterOrValue) => {
    sorting.value =
      typeof updaterOrValue === "function"
        ? updaterOrValue(sorting.value)
        : updaterOrValue;
  },
  onColumnFiltersChange: (updaterOrValue) => {
    columnFilters.value =
      typeof updaterOrValue === "function"
        ? updaterOrValue(columnFilters.value)
        : updaterOrValue;
  },
  onGlobalFilterChange: (updaterOrValue) => {
    globalFilter.value =
      typeof updaterOrValue === "function"
        ? updaterOrValue(globalFilter.value)
        : updaterOrValue;
  },
  getCoreRowModel: getCoreRowModel(),
  getSortedRowModel: getSortedRowModel(),
  getFilteredRowModel: getFilteredRowModel(),
  getFacetedRowModel: getFacetedRowModel(),
  getFacetedUniqueValues: getFacetedUniqueValues(),
  getFacetedMinMaxValues: getFacetedMinMaxValues(),
  debugTable: true,
});

watch(
  () => projectStore.projects,
  () => {
    dataProject.value = projectStore.projects;
  }
);

onMounted(async () => {
  try {
    await projectStore.fetchProjects();
    await taskStore.fetchProjectTasks();
    dataProject.value = projectStore.projects.map((project) => ({
      ...project,
      tasks: taskStore.getTasksByProject(project.id).length,
      enableFiltering: false,
    }));
    console.log(dataProject.value);
  } catch (err) {
    console.error(err);
  }
});
</script>

<style lang="scss" scoped>
.p-2 {
  padding: 1rem;

  table {
    width: 100%;
    border-collapse: collapse;
    background-color: #f9f9f9;
    font-size: 0.9rem;

    thead {
      background-color: #f1f1f1;
      .column-name {
        display: flex;
      }
      th {
        padding: 0.75rem 1rem;
        text-align: left;
        font-weight: bold;
        border-bottom: 2px solid #ddd;
        cursor: default;

        &.cursor-pointer {
          cursor: pointer;
          &:hover {
            background-color: #e9e9e9;
          }
        }
      }
    }

    tbody {
      tr {
        &:nth-child(odd) {
          background-color: #fcfcfc;
        }
        &:hover {
          background-color: #f0f8ff;
          cursor: pointer;
        }

        td {
          padding: 0.75rem 1rem;
          border-bottom: 1px solid #ddd;
          text-align: left;
        }
      }
    }

    tfoot {
      background-color: #f1f1f1;

      th {
        padding: 0.75rem 1rem;
        border-top: 2px solid #ddd;
        text-align: left;
        font-weight: normal;
      }
    }
  }
}
</style>
