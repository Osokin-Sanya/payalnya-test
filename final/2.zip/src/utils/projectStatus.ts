import type { Task, Project, ProjectStatus } from '@/types'
 
export function calculateProjectStatus(tasks: Task[]): ProjectStatus {
  if (tasks.length === 0) return 'new'

  const hasInProgress = tasks.some((task) => task.status === 'in-progress')
  if (hasInProgress) return 'in-progress'

  const allDone = tasks.every((task) => task.status === 'done')
  if (allDone) return 'completed'

  const allNew = tasks.every((task) => task.status === 'new')
  if (allNew) return 'new'

  return 'in-progress'
}

export function updateProjectStatus(project: Project, tasks: Task[]): Project {
  const newStatus = calculateProjectStatus(tasks)
  if (project.status !== newStatus) {
    return { ...project, status: newStatus }
  }
  return project
}


export const updateProjectStatus2 = (tasks: Task[]): string => {
  if (tasks.length === 0) {
    return "not started"; // No tasks means the project hasn't started
  }

  const statuses = tasks.map(task => task.status);

  if (statuses.every(status => status === "done")) {
    return "completed"; // All tasks are done
  }

  if (statuses.some(status => status === "in-progress")) {
    return "in progress"; // At least one task is in progress
  }

  return "not started"; // Default case if no tasks are in progress or done
};